## Getting Started
clone the project using

```git clone https://github.com/ykaner/moodle-filter```  
nothing too fancy.

## Running and debugging
Go into `chrome://extentions` and turn Developer Mode on.  
Click `Load unpacked extention...` and select the project folder  
While debugging remember to go back to the extention page and reload the extention!

